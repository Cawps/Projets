﻿namespace AP7_Breggion_Quentin
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbMSinput = new System.Windows.Forms.Label();
            this.lbIPinput = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbHotes = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbNetIP = new System.Windows.Forms.Label();
            this.lbClass = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbMSdecimal = new System.Windows.Forms.Label();
            this.lbMSbin = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lbNewCIDR = new System.Windows.Forms.Label();
            this.numSR = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lbCIDRactuel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSR)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbCIDRactuel);
            this.groupBox1.Controls.Add(this.lbMSinput);
            this.groupBox1.Controls.Add(this.lbIPinput);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(12, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 104);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Adresse IP et masque de sous-réseau saisie";
            // 
            // lbMSinput
            // 
            this.lbMSinput.AutoSize = true;
            this.lbMSinput.Location = new System.Drawing.Point(138, 50);
            this.lbMSinput.Name = "lbMSinput";
            this.lbMSinput.Size = new System.Drawing.Size(88, 13);
            this.lbMSinput.TabIndex = 3;
            this.lbMSinput.Text = "255.255.255.255";
            // 
            // lbIPinput
            // 
            this.lbIPinput.AutoSize = true;
            this.lbIPinput.Location = new System.Drawing.Point(138, 27);
            this.lbIPinput.Name = "lbIPinput";
            this.lbIPinput.Size = new System.Drawing.Size(88, 13);
            this.lbIPinput.TabIndex = 2;
            this.lbIPinput.Text = "255.255.255.255";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Masque de sous-réseau :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Adresse IP :";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(629, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "INTERFACE DE TRAITEMENT";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbHotes);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.lbNetIP);
            this.groupBox2.Controls.Add(this.lbClass);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(328, 62);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(310, 90);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informations de l\'adresse IP réseau";
            // 
            // lbHotes
            // 
            this.lbHotes.AutoSize = true;
            this.lbHotes.Location = new System.Drawing.Point(228, 69);
            this.lbHotes.Name = "lbHotes";
            this.lbHotes.Size = new System.Drawing.Size(76, 13);
            this.lbHotes.TabIndex = 5;
            this.lbHotes.Text = "4 294 967 296";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(216, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "Nombre maximum d\'hôtes par sous-réseaux :";
            // 
            // lbNetIP
            // 
            this.lbNetIP.AutoSize = true;
            this.lbNetIP.Location = new System.Drawing.Point(138, 23);
            this.lbNetIP.Name = "lbNetIP";
            this.lbNetIP.Size = new System.Drawing.Size(88, 13);
            this.lbNetIP.TabIndex = 3;
            this.lbNetIP.Text = "255.255.255.255";
            // 
            // lbClass
            // 
            this.lbClass.AutoSize = true;
            this.lbClass.Location = new System.Drawing.Point(138, 46);
            this.lbClass.Name = "lbClass";
            this.lbClass.Size = new System.Drawing.Size(35, 13);
            this.lbClass.TabIndex = 2;
            this.lbClass.Text = "Erreur";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "IP de l\'adresse réseau :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Classe de l\'adresse IP :";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbMSdecimal);
            this.groupBox3.Controls.Add(this.lbMSbin);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Location = new System.Drawing.Point(328, 158);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(310, 76);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Conversions du masque de sous-réseau";
            // 
            // lbMSdecimal
            // 
            this.lbMSdecimal.AutoSize = true;
            this.lbMSdecimal.Location = new System.Drawing.Point(77, 50);
            this.lbMSdecimal.Name = "lbMSdecimal";
            this.lbMSdecimal.Size = new System.Drawing.Size(88, 13);
            this.lbMSdecimal.TabIndex = 3;
            this.lbMSdecimal.Text = "255.255.255.255";
            // 
            // lbMSbin
            // 
            this.lbMSbin.AutoSize = true;
            this.lbMSbin.Location = new System.Drawing.Point(77, 27);
            this.lbMSbin.Name = "lbMSbin";
            this.lbMSbin.Size = new System.Drawing.Size(208, 13);
            this.lbMSbin.TabIndex = 2;
            this.lbMSbin.Text = "00000000.00000000.00000000.00000000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "En décimal :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "En binaire :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.lbNewCIDR);
            this.groupBox4.Controls.Add(this.numSR);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Location = new System.Drawing.Point(12, 158);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(310, 76);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(185, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 20);
            this.button1.TabIndex = 5;
            this.button1.Text = "CALCULER";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbNewCIDR
            // 
            this.lbNewCIDR.AutoSize = true;
            this.lbNewCIDR.Location = new System.Drawing.Point(99, 50);
            this.lbNewCIDR.Name = "lbNewCIDR";
            this.lbNewCIDR.Size = new System.Drawing.Size(16, 13);
            this.lbNewCIDR.TabIndex = 3;
            this.lbNewCIDR.Text = "...";
            // 
            // numSR
            // 
            this.numSR.Location = new System.Drawing.Point(185, 14);
            this.numSR.Maximum = new decimal(new int[] {
            0,
            1,
            0,
            0});
            this.numSR.Name = "numSR";
            this.numSR.Size = new System.Drawing.Size(93, 20);
            this.numSR.TabIndex = 1;
            this.numSR.ThousandsSeparator = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(173, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Nombre de sous-réseaux souhaité :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 50);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Nouveau CIDR :";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 247);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "QUITTER";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(537, 247);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "RETOUR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(93, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "CIDR :";
            // 
            // lbCIDRactuel
            // 
            this.lbCIDRactuel.AutoSize = true;
            this.lbCIDRactuel.Location = new System.Drawing.Point(138, 74);
            this.lbCIDRactuel.Name = "lbCIDRactuel";
            this.lbCIDRactuel.Size = new System.Drawing.Size(16, 13);
            this.lbCIDRactuel.TabIndex = 6;
            this.lbCIDRactuel.Text = "...";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(648, 282);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbMSinput;
        private System.Windows.Forms.Label lbIPinput;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbNetIP;
        private System.Windows.Forms.Label lbClass;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbHotes;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbMSdecimal;
        private System.Windows.Forms.Label lbMSbin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbNewCIDR;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown numSR;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbCIDRactuel;
    }
}