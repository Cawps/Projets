﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP7_Breggion_Quentin
{
    public partial class Form2 : Form
    {
        //-------------------------------------||---------------------------------------------------------------------------------||-----------------------------------------//
        //-------------------------------------||---------------------------PARTIE CHARGEMENT-------------------------------------||-----------------------------------------//
        //-------------------------------------\/---------------------------------------------------------------------------------\/-----------------------------------------//
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)//bouton retour
        {
            Form1 IntConf = new Form1();
            IntConf.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)//bouton quitter
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lbIPinput.Text = Program.IPinput;
            lbMSinput.Text = Program.MSinput;
            int j = 0;

            Program.NetIP = "";//On vide la chaine à chaque fois que l'évènement se lance

            for(int i = 0, k=0; i<32; ++i)
            {
                if (Program.MSbin.Substring(i, 1) == "1")
                {
                    ++k;
                }
                lbCIDRactuel.Text = "/" + k;
            }

            for (int i = 0; i < 32; ++i)//Calcul de l'adresse réseau en binaire
            {
                if (Program.IPbin.Substring(i, 1) == Program.MSbin.Substring(i, 1) && Program.MSbin.Substring(i, 1) == "1")
                {
                    Program.NetIP += "1";
                }
                else
                {
                    Program.NetIP += "0";
                }
            }

            for (int k = 0; k < 8; ++k)//Conversion de l'adresse réseau binaire en décimal. Je n'ai pas résussi à le mettre dans une autre boucle "for"
            {
                if (Program.NetIP.Substring(k, 1) == "1")
                {
                    Program.NetDecimal[0] = (int)Math.Pow(2, 7 - k) + Program.NetDecimal[0];
                }
            }
            for (int k = 0; k < 8; ++k)
            {
                if (Program.NetIP.Substring(k + 8, 1) == "1")
                {
                    Program.NetDecimal[1] = (int)Math.Pow(2, 7 - k) + Program.NetDecimal[1];
                }
            }
            for (int k = 0; k < 8; ++k)
            {
                if (Program.NetIP.Substring(k + 16, 1) == "1")
                {
                    Program.NetDecimal[2] = (int)Math.Pow(2, 7 - k) + Program.NetDecimal[2];
                }
            }
            for (int k = 0; k < 8; ++k)
            {
                if (Program.NetIP.Substring(k + 24, 1) == "1")
                {
                    Program.NetDecimal[3] = (int)Math.Pow(2, 7 - k) + Program.NetDecimal[3];
                }
            }

            lbNetIP.Text = $"{Program.NetDecimal[0]}.{Program.NetDecimal[1]}.{Program.NetDecimal[2]}.{Program.NetDecimal[3]}";

            //-------------------------------------------------------------------------------------------------------------------------------------------//

            if (Program.NetDecimal[0]>=0 && Program.NetDecimal[0]<=126)//vérifie la classe de l'adresse IP, j'aurais pu utiliser Program.classA ou classB ou classC
            {
                lbClass.Text = "A";
            }
            else if (Program.NetDecimal[0] >= 128 && Program.NetDecimal[0] <= 191)
            {
                lbClass.Text = "B";
            }
            else if (Program.NetDecimal[0] >= 192 && Program.NetDecimal[0] <= 223)
            {
                lbClass.Text = "C";
            }

            //------------------------------------------------------------------------------------------------------------------------------------------//

            if (Program.count == 1)
            {
                lbMSdecimal.Text = $"{Program.MSdecimal[0]}.{Program.MSdecimal[1]}.{Program.MSdecimal[2]}.{Program.MSdecimal[3]}";
            }
            else if (Program.count == 4)
            {
                lbMSdecimal.Text = Program.MSinput;
            }
            else
            {
                lbMSdecimal.Text = "Erreur inattendue";
            }

            //Calculer le nombre d'hôtes :
            int hôtes=0;

            for (int i=0; i<32; ++i)
            {
                if (Program.MSbin.Substring(i,1) == "0")
                {
                    ++hôtes;
                }
            }
            for (int i = 1; i < 4; ++i)//Boucle pour mettre 3 points
            {
                Program.MSbin = Program.MSbin.Insert(i * 8 + j, ".");
                j = j + 1;
            }

            lbMSbin.Text = Program.MSbin;
            lbHotes.Text = Convert.ToString(Math.Pow(2, hôtes)-2);
        }

        //-------------------------------------||---------------------------------------------------------------------------------||-----------------------------------------//
        //-------------------------------------||---------------------------PARTIE NOUVEAU CIDR-----------------------------------||-----------------------------------------//
        //-------------------------------------\/---------------------------------------------------------------------------------\/-----------------------------------------//

        private void button1_Click(object sender, EventArgs e)//Calcul un nouveau CIDR à partir du nombre de sous-réseaux demandé
        {
            int newSR = (int)numSR.Value, i=0, CIDR=0;

            while (newSR > (int)Math.Pow(2, i))
            {
                ++i;
            }

            for (int k=0; k<35; ++k)
            {
                if (Program.MSbin.Substring(k, 1) == "1")
                {
                    ++CIDR;
                }
            }

            if ((CIDR + i) > 30)
            {
                MessageBox.Show($"Le nombre maximum de sous-réseaux est de {(int)Math.Pow(2, i-1)}");
            }
            else if ((CIDR + i) <= 30)
            {
                lbNewCIDR.Text = "/" + Convert.ToString(CIDR + i);
            }
        }
    }
}
