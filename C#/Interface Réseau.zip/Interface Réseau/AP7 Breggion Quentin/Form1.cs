﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AP7_Breggion_Quentin
{
    public partial class Form1 : Form
    {
        //-------------------------------------||---------------------------------------------------------------------------------||-----------------------------------------//
        //-------------------------------------||-------------------------PARTIE CHARGMENT DE LA FENETRE--------------------------||-----------------------------------------//
        //-------------------------------------\/---------------------------------------------------------------------------------\/-----------------------------------------//

        public static bool EnabledCondition1 = true, EnabledCondition2 = true, inputBtn1 = false, inputBtn2 = false;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)//on reset toutes les variables au chargement de form1 afin de pouvoir utiliser plusieurs fois l'application sans la reset (certain varibale ne sont pas ici car elles sont reset dans d'autres event)
        {
            btnV.Enabled = false;
            btnMS.Enabled = false;
            lbMSG.Text = "";
            Program.bin = "";
            Program.NetIP = "";
            Program.MSinput = "";
            Program.IPinput = "";
            Program.IPbin = "";
            Program.MSbin = "";
            for(int i=0; i<4; ++i)
            {
                Program.NetDecimal[i] = 0;
            }
        }

        //-------------------------------------||---------------------------------------------------------------------------------||-----------------------------------------//
        //-------------------------------------||------------------------------------PARTIE IP------------------------------------||-----------------------------------------//
        //-------------------------------------\/---------------------------------------------------------------------------------\/-----------------------------------------//

        private void button1_Click(object sender, EventArgs e)//Je n'ai pas renommé le bouton car il n'y en a que deux
        {
            string[] ip = tbIP.Text.Split('.'); //Le programme prend les inputs et les rentre dans le tableau "ip" lorsqu'ils sont séparés par des points
            int count = ip.Count(); //Cette variable locale à l'event button1_Click compte le nombre d'éléments du tableau
            int display = 0;
            bool local=false, protectionAntiBoucle = true, ClasseIsGood = true;
            Form1.EnabledCondition1 = false;
            Form1.inputBtn1 = true;

            if (count != 4)
            {
                lbIPbin.Text = "Une IP est composée de 4 octets";
            }
            else if (count == 4)//L'ip doit contenir 4 éléments dans le tableau "ip"
            {
                if (ip[0] == "127")//L'ip 127 sur le premier octet est une adresse local réservé
                {
                    local = true;
                }
                for (int i = 0; i < count; ++i)//boucle qui va répéter 4 fois normalement (je laisse count si jamais il y a un bug)
                {
                    bool notChar = int.TryParse(ip[i], out int num);//va vérifier si l'utilisateur entre des entiers, si oui num va être affecté à chaque élément du tableau grâce à la boucle "for"
                    if (notChar)//si l'utilisateur à entrer des entiers "notChar" est vraie
                    {
                        if (num >= 0 && num <= 255)//vérifie si chaque octet de l'ip est entre 0 et 255
                        {
                            if (protectionAntiBoucle)//Protection contre la boucle afin d'optimiser le programme
                            {
                                if (int.Parse(ip[0]) >= 0 && int.Parse(ip[0]) < 127)
                                {
                                    Program.classeA = true;
                                }
                                else if (int.Parse(ip[0]) > 127 && int.Parse(ip[0]) <= 191)
                                {
                                    Program.classeB = true;
                                }
                                else if (int.Parse(ip[0]) >= 192 && int.Parse(ip[0]) <= 223)
                                {
                                    Program.classeC = true;
                                }
                                else if (int.Parse(ip[0]) > 223)
                                {
                                    lbIPbin.Text = "Les classes D et E ne sont pas prises en charge\nLa valeur du premier octet doit être strictement inférieur à 224";
                                    ClasseIsGood = false;
                                }
                                protectionAntiBoucle = false;
                            }
                            
                            ip[i] = Convert.ToString(int.Parse(ip[i]), 2);//va convertir chaque élément du tableau d'entier
                            while (ip[i].Length < 8)
                            {
                                ip[i] = "0" + ip[i];
                            }
                            ++display;
                        }
                        else
                        {
                            lbIPbin.Text = "Les octets d'une IP doivent être compris entre 0 et 255";
                        }
                    }
                    else if (ip[i] == "")//va vérifier si après un point, qui définit un élément du tableau, il y a au moins quelque chose pour chaque octet
                    {
                        lbIPbin.Text = "Il y a un point mais rien après...";
                    }
                    else
                    {
                        lbIPbin.Text = "Il faut entrer des entiers";
                    }
                }
                if (local)//on affcihe un message d'erreur si l'utilisateur saisit 127 en premier octet
                {
                    lbIPbin.Text = "127 est l'adresse local";
                }
                else if (ip[3] != "" && display == 4 && ClasseIsGood == true)//si tout est bon on affiche l'ip en binaire et on sauvegarde l'ip en décimal, en binaire sans les points et on active le bouton pour vérifier le masque de sous-réseau
                {
                    lbIPbin.Text = $"{ip[0]}.{ip[1]}.{ip[2]}.{ip[3]}";
                    Program.IPbin = $"{ip[0]}.{ip[1]}.{ip[2]}.{ip[3]}";
                    Program.IPinput = tbIP.Text;
                    Program.IPbin = Program.IPbin.Substring(0, 8) + Program.IPbin.Substring(9, 8) + Program.IPbin.Substring(18, 8) + Program.IPbin.Substring(27, 8);
                    Form1.EnabledCondition1 = true;
                    btnMS.Enabled = true;
                }
            }
            else//si count n'est pas égal à 4 ou s'il n'est pas égal à autre chose que 4 on affiche un message d'erreur (on sait jamais)
            {
                lbIPbin.Text = "Erreur inattendue";
            }

            if (Form1.EnabledCondition1 == true && Form1.EnabledCondition2 == true && Form1.inputBtn1 == true && Form1.inputBtn2 == true)//va vérifier si l'utilisateur peut accéder au bouton qui permet d'accéder au deuxième formulaire (form2)
            {
                btnV.Enabled = true;
                lbMSG.Text = "";
            }
            else if ((Form1.EnabledCondition1 == false || Form1.EnabledCondition2 == false) && Form1.inputBtn2 == true)//sinon il affiche un message d'erreur (qui s'affichera prématurement mais je n'ai plus de temps)
            {
                lbMSG.Text = "Vous devez entrer des informations\r\nvalides pour continuer";
            }
        }

        //-------------------------------------||---------------------------------------------------------------------------------||-----------------------------------------//
        //-------------------------------------||---------------------------PARTIE MASQUE DE SOUS-RESEAU--------------------------||-----------------------------------------//
        //-------------------------------------\/---------------------------------------------------------------------------------\/-----------------------------------------//

        private void button2_Click(object sender, EventArgs e)
        {
            this.lbMSbin.Location = new Point(6, 77);//On replace le label qui afficher le masque en binaire
            string[] MS = tbMS.Text.Split('.');
            Program.count = MS.Count();
            Program.bin="";
            Form1.EnabledCondition2 = false;
            Form1.inputBtn2 = true;

            if (tbMS.Text == "")//On vérifie si 'lutilisateur à bien entré qqc
            {
                lbMSbin.Text = "Ca va être difficile à calculer...";
            }
            else if (Program.count == 1)//sous forme CIDR
            {
                string CIDR = MS[0].Remove(0,1);//On enlève le premier charactère de la chaine
                if (MS[0] == $"/{CIDR}")//On vérifie si le premier charactère est un slash
                {
                    if (int.TryParse(CIDR, out int num))//On vérifie si des entiers sont bien entrés
                    {
                        if (num < 8 || num > 30)//On vérifie que le CIDR est un nombre entre 8 et 30 (8 car la classe minimum que l'on prend en compte est la classe A et 30 car 2^(32-30)-2 nous donne 2 hôtes ce qui est le minimum)
                        {
                            lbMSbin.Text = "Les octets de la notation CIDR sont compris entre 8 et 30\n(car nous n'avons pas fait les autres classes)";
                        }
                        else if (num >= 8 && num <= 30)
                        {
                            int k=0;
                            for (int i = 0; i < num; ++i)//On convertit le CIDR en nombre de "1"
                            {
                                Program.bin += "1";
                            }
                            while (Program.bin.Length < 32)//On ajoute des "0" après les "1"
                            {
                                Program.bin += "0";
                            }
                            for (int i=1; i<4; ++i)//Boucle pour mettre 3 points
                            {
                                Program.bin = Program.bin.Insert(i*8+k, ".");
                                k = k + 1;
                            }
                            lbMSbin.Text = Program.bin;
                            Program.MSinput = tbMS.Text;
                            Program.MSbin = Program.bin.Substring(0, 8) + Program.bin.Substring(9, 8) + Program.bin.Substring(18, 8) + Program.bin.Substring(27, 8);

                            for (int i = 0; i < 4; ++i)//On reset le tableau pour pouvoir se servir de l'application plusieurs fois sans la fermer
                            {
                                Program.MSdecimal[i] = 0;
                            }
                            for (int i = 0; i < 8; ++i)//On convertit chaque octet en décimal
                            {
                                if (Program.bin.Substring(i, 1) == "1")
                                {
                                    Program.MSdecimal[0] = (int)Math.Pow(2, 7 - i) + Program.MSdecimal[0];
                                }
                            }
                            for (int i = 0; i < 8; ++i)
                            {
                                if (Program.bin.Substring(i + 9, 1) == "1")
                                {
                                    Program.MSdecimal[1] = (int)Math.Pow(2, 7 - i) + Program.MSdecimal[1];
                                }
                            }
                            for (int i = 0; i < 8; ++i)
                            {
                                if (Program.bin.Substring(i + 18, 1) == "1")
                                {
                                    Program.MSdecimal[2] = (int)Math.Pow(2, 7 - i) + Program.MSdecimal[2];
                                }
                            }
                            for (int i = 0; i < 8; ++i)
                            {
                                if (Program.bin.Substring(i + 27, 1) == "1")
                                {
                                    Program.MSdecimal[3] = (int)Math.Pow(2, 7 - i) + Program.MSdecimal[3];
                                }
                            }
                        }
                        if (num >= 8 && Program.classeA == true)//On vérifie que le premier octet et le CIDR concorde
                        {
                            EnabledCondition2 = true;
                        }
                        else if (num >= 16 && Program.classeB == true)
                        {
                            EnabledCondition2 = true;
                        }
                        else if (num >= 24 && Program.classeC == true)
                        {
                            EnabledCondition2 = true;
                        }
                        else
                        {
                            lbMSbin.Text = "Le masque ne correspond pas à la classe de l'IP";
                        }
                    }
                    else
                    {
                        lbMSbin.Text = "Il faut entrer des entiers";
                    }
                }
                else
                {
                    lbMSbin.Text = "La notation CIDR commence toujours par un slash : /";
                }
            }
            else if(Program.count == 4)//sous forme décimal
            {
                int display = 0;
                bool huitPuisTrente = false, unPuisZero = false;

                for (int i = 0; i < Program.count; ++i)//boucle qui va répéter 4 fois normalement (je laisse count si jamais il y a un bug)
                {
                    bool notCharInFor = int.TryParse(MS[i], out int num);
                    if (notCharInFor)
                    {
                        if (num >= 0 && num <= 255)
                        {
                            if (num == 0 || num == 128 || num == 192 || num == 224 || num == 240 || num == 248 || num == 252 || num == 254 || num == 255)
                            {
                                MS[i] = Convert.ToString(num, 2);
                                while (MS[i].Length < 8)
                                {
                                    MS[i] = "0" + MS[i];
                                }
                                ++display;
                            }
                            else
                            {
                                MS[i] = Convert.ToString(num, 2);
                                while (MS[i].Length < 8)
                                {
                                    MS[i] = "0" + MS[i];
                                }
                                lbMSbin.Text = "Les octets d'un masque de sous-réseau sont des sommes de\npuissance de 2 décroissante en partant de 2 exposant 7";
                            }
                        }
                        else
                        {
                            lbMSbin.Text = "Les octets d'un masque de sous-réseau doivent être compris entre 0 et 255";
                        }
                    }
                    else if (MS[i] == "")
                    {
                        lbMSbin.Text = "Il y a un point mais rien après...";
                    }
                    else
                    {
                        lbMSbin.Text = "Il faut entrer des entiers";
                    }
                }

                bool notCharOutFor1 = int.TryParse(MS[0], out int num1);//Un tableau aurait pu être fait avec une boucle mais parfois la simplicité est préférable
                bool notCharOutFor2 = int.TryParse(MS[1], out int num2);
                bool notCharOutFor3 = int.TryParse(MS[2], out int num3);
                bool notCharOutFor4 = int.TryParse(MS[3], out int num4);
                bool RespectClasse = false;

                if (notCharOutFor1 && notCharOutFor2 && notCharOutFor3 && notCharOutFor4)//On vérifie qu'on trvail avec des entiers
                {
                    //------------------------------------------------//------------------------------------------------//

                    string verifMS = MS[0] + MS[1] + MS[2] + MS[3];//Vérifie que des 1 sont bien suivit de 0 et pas l'inverse

                    for (int i = 0; i < 31; ++i)//la boucle va se répéter 31 fois car la longueur de la chaine que l'on veut vérifier est de 2
                    {
                        if (verifMS.Substring(i) == "01")
                        {
                            unPuisZero = true;
                        }
                        else
                        {
                            lbMSbin.Text = "Ce masque est n'existe pas";//sinon le masque n'esxiste pas
                        }
                    }

                    //------------------------------------------------//------------------------------------------------//

                    byte MSnum1 = Convert.ToByte(Convert.ToString(num1), 2);
                    byte MSnum2 = Convert.ToByte(Convert.ToString(num2), 2);
                    byte MSnum3 = Convert.ToByte(Convert.ToString(num3), 2);
                    byte MSnum4 = Convert.ToByte(Convert.ToString(num4), 2);

                    if (MSnum1 > 0 && MSnum4 < 255)//On vérifie que le premier et le dernier octet sont compris entre 0 et 255
                    {
                        huitPuisTrente = true;

                        if (MSnum1 == 255 && Program.classeA == true)
                        {
                            RespectClasse = true;
                        }
                        else if (MSnum2 == 255 && Program.classeB == true)
                        {
                            RespectClasse = true;
                        }
                        else if (MSnum3 == 255 && Program.classeC == true)
                        {
                            RespectClasse = true;
                        }
                    }
                    else
                    {
                        lbMSbin.Text = "Le masque de sous-réseau ne peut avoir son premier\noctet inférieur à 0 et son dernier à 255";
                    }
                }
                else
                {
                    lbMSbin.Text = "Il faut entrer des entiers";
                }

                if (MS[3] != "" && display == 4 && unPuisZero == false && huitPuisTrente == true && RespectClasse == true)//Si toutes les conditions sont respectées alors là seulement 
                {
                    lbMSbin.Text = $"{MS[0]}.{MS[1]}.{MS[2]}.{MS[3]}";
                    Program.MSbin = MS[0]+MS[1]+MS[2]+MS[3];
                    Program.MSinput = tbMS.Text;
                    Form1.EnabledCondition2 = true;
                }
                else if(unPuisZero)
                {
                    lbMSbin.Text = "Un masque de sous réseau ne peut avoir un octet suivi\nd'un autre qui lui est supérieur ou égal s'il n'est égal à 255";
                }
                else if (huitPuisTrente == false)
                {
                    lbMSbin.Text = "Ce masque n'existe pas";
                }
                else if(RespectClasse==false)
                {
                    lbMSbin.Text = "Le masque ne correspond pas à la classe de l'IP";
                }
            }
            else
            {
                if (Program.count == 1 && MS[0].Substring(0) != "/")
                {
                    lbMSbin.Text = "La notation CIDR commence toujours par un slash : /";
                }
                else if (Program.count != 1 || Program.count != 4)
                {
                    lbMSbin.Text = "Un masque de sous-réseau est composée de 4 octets ou d'un\nslash suivi de nombre en fonction de la notation";
                }
            }
            if (Form1.EnabledCondition1 == true && Form1.EnabledCondition2 == true && Form1.inputBtn1 == true && Form1.inputBtn2 == true)
            {
                btnV.Enabled = true;
                lbMSG.Text = "";
            }
            else if ((Form1.EnabledCondition1 == false || Form1.EnabledCondition2 == false) && Form1.inputBtn1 == true)
            {
                btnV.Enabled = false;
                lbMSG.Text = "Vous devez entrer des informations\r\nvalides pour continuer";
            }
        }

        //-------------------------------------||---------------------------------------------------------------------------------||-----------------------------------------//
        //-------------------------------------||---------------------------PARTIE BOUTONS DE FORM--------------------------------||-----------------------------------------//
        //-------------------------------------\/---------------------------------------------------------------------------------\/-----------------------------------------//

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnV_Click(object sender, EventArgs e)
        {
            Form2 IntTreat = new Form2();
            IntTreat.Show();
            this.Hide();
        }
    }
}