﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AP7_Breggion_Quentin
{
    internal static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        public static string IPinput, MSinput, MSbin, IPbin, NetIP/*Adresse du réseau en binaire*/, bin;
        public static int count; 
        public static int[] NetDecimal = new int[4];//Adresse du réseau en décimal
        public static int[] MSdecimal = new int[4];
        public static bool classeA = false, classeB = false, classeC = false;
    }
}
